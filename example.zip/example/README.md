# Example site using https://github.com/gbif/ssg

Requires Node to be installed

Install dependencies with
```
npm install
```

Run development with 
```
gulp
```

Build to prod with
```
gulp --production
```

For a more complete introduction see https://github.com/gbif/ssg and the more complex example and documentation site https://github.com/gbif/ssg-example

To update to newest version update gbif-ssg dependency in bower.json and package.json to newest commit

```
"gbif-ssg": "gbif/ssg.git#[INSERT NEWEST COMMIT]"
//example
"gbif-ssg": "gbif/ssg.git#0f7f3cb3563017502c7962fb056a25dfcd1ab8a8",
```